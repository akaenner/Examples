//
//  Swift.swift
//  TestFramework
//
//  Created by andreas on 17.10.24.
//

import Foundation

func doInSwift()
{
    print("doInSwift")
}
