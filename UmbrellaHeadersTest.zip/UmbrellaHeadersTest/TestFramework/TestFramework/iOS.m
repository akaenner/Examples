//
//  Mac.m
//  TestFramework
//
//  Created by andreas on 17.10.24.
//

#import "iOS.h"

void doOnIOS(void) {
    NSLog(@"doOnIOS");
}
