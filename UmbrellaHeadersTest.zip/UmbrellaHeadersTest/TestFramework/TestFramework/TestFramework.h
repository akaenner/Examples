//
//  TestFramework.h
//  TestFramework
//
//  Created by andreas on 17.10.24.
//

#import <Foundation/Foundation.h>

#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR || TARGET_OS_VISION)

#import <TestFramework/iOS.h>

#elif TARGET_OS_MAC

#import <TestFramework/Mac.h>

#endif
