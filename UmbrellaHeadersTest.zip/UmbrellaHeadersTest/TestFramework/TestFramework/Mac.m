//
//  Mac.m
//  TestFramework
//
//  Created by andreas on 17.10.24.
//

#import "Mac.h"

void doOnMac(void) {
    NSLog(@"doOnMac");
}
