//
//  AppDelegate.h
//  iOSApp
//
//  Created by andreas on 28.10.24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

