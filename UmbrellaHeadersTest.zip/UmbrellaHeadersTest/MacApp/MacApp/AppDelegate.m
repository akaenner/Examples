//
//  AppDelegate.m
//  UmbrellaHeadersApp
//
//  Created by andreas on 28.10.24.
//

#import "AppDelegate.h"

#import <TestFramework/TestFramework.h>

@interface AppDelegate ()

@property (strong, atomic) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {

    doOnMac();
    
}



@end
