//
//  AppDelegate.h
//  UmbrellaHeadersApp
//
//  Created by andreas on 28.10.24.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

