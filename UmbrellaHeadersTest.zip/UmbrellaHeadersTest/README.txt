This project demonstrates a bug in Xcode where it incorrectly shows a warning about missing headers in a framework's umbrella header.

Here's the setup:

Xcode 16.x

Two apps: One for macOS (MacApp) and one for iOS (iOSApp).
One framework: A universal framework called TestFramework used by both apps.
Conditional headers: TestFramework uses #if TARGET_... statements to include headers specific to macOS or iOS.

The problem:

Xcode displays these warnings:
When building MacApp: "Umbrella header for module 'TestFramework' does not include header 'iOS.h'"
When building iOSApp: "Umbrella header for module 'TestFramework' does not include header 'Mac.h'"

Conditions for the warning:

- The "incomplete-umbrella" warning is enabled (not disabled).
- You've cleaned the build folder ("Clean Build Folder...") before building.
- TestFramework includes a Swift file.
- TestFramework is built for multiple platforms (macOS, iOS).

Weird behavior:

Sometimes the warning disappears after building again without cleaning the build folder first.

Workaround (not always reliable):

Adding the compiler flag OTHER_SWIFT_FLAGS = -Xcc -Wno-incomplete-umbrella suppresses the warning in this example project, but not always in our actual app.

(You can disable the warning from within Shared.xcconfig)

Any suggestions on how to reliably eliminate these warnings would be greatly appreciated!
